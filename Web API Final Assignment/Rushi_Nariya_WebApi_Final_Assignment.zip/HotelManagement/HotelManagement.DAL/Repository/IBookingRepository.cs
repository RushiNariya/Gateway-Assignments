﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelManagement.Models;

namespace HotelManagement.DAL.Repository
{
    public interface IBookingRepository
    {
        string CreateBooking(Bookings booking);
        string UpdateBooking(Bookings booking);

        //Optional to Cancelled/Definitive Status
        string UpdateBooking(int bookingId, string status);

        //Deleted Status (Soft Delete)
        string DeleteBooking(int bookingId);
        bool CheckRoomAvailability(int roomId, DateTime date);

    }
}
