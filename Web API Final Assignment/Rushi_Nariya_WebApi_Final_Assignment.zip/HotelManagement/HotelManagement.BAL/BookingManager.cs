﻿using HotelManagement.BAL.Interface;
using HotelManagement.DAL.Repository;
using HotelManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagement.BAL
{
    public class BookingManager : IBookingManager
    {
        private readonly IBookingRepository _bookingRepository;
        public BookingManager(IBookingRepository bookingRepository)
        {
            _bookingRepository = bookingRepository;
        }
        public bool CheckRoomAvailability(int roomId, DateTime date)
        {
            return _bookingRepository.CheckRoomAvailability(roomId, date);
        }

        public string CreateBooking(Bookings booking)
        {
            return _bookingRepository.CreateBooking(booking);
        }

        public string DeleteBooking(int bookingId)
        {
            return _bookingRepository.DeleteBooking(bookingId);
        }

        public string UpdateBooking(Bookings booking)
        {
            return _bookingRepository.UpdateBooking(booking);
        }

        public string UpdateBooking(int bookingId, string status)
        {
            return _bookingRepository.UpdateBooking(bookingId, status);
        }
    }
}
