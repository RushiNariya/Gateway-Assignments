﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelManagement.Models;

namespace HotelManagement.BAL.Interface
{
    public interface IHotelManager
    {
        List<Hotels> GetAllHotels();
        string CreateHotel(Hotels hotel);
        Hotels GetHotel(int id);
    }
}
