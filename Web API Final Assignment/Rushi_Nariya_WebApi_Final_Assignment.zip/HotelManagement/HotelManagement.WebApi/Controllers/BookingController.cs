﻿using HotelManagement.BAL.Interface;
using HotelManagement.Models;
using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace HotelManagement.WebApi.Controllers
{
    public class BookingController : ApiController
    {
        private readonly IBookingManager _bookingManager;

        public BookingController(IBookingManager bookingManager)
        {
            _bookingManager = bookingManager;
        }

        // GET: api/Booking
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        // GET: api/Booking/5
        //public string Get(int id)
        //{
        //    return "value";
        //}

        // POST: api/Booking

        [HttpPost]
        [Route("api/Booking")]
        public IHttpActionResult Post([FromBody]Bookings booking)
        {
            string userId = User.Identity.GetUserId();
            if(userId == null)
            {
                return Unauthorized();
            }

            booking.BookingBy = userId;

            string response = _bookingManager.CreateBooking(booking);
            if (response.Equals("Error"))
            {
                return NotFound();
            }
            return Ok();
        }

        // PUT: api/Booking/5
        [HttpPut]
        [Route("api/Booking/{bookingId}/{status}")]
        public IHttpActionResult Put(int bookingId, string status)
        {
            string response = _bookingManager.UpdateBooking(bookingId, status);
            if (response.Equals("null"))
            {
                return NotFound();
            }
            return Ok();
        }

        // PUT: api/Booking/{BookingObject}
        [HttpPut]
        [Route("api/Booking")]
        public IHttpActionResult Put([FromBody]Bookings booking)
        {
            string response = _bookingManager.UpdateBooking(booking);
            if (response.Equals("null"))
            {
                return NotFound();
            }
            return Ok();
        }

        // DELETE: api/Booking/5
        //Delete By Booking id
        public IHttpActionResult Delete(int id)
        {
            string response = _bookingManager.DeleteBooking(id);
            if (response.Equals("null"))
            {
                return NotFound();
            }
            return Ok();
        }

        // GET: api/booking?roomId={roomId}&date={date}
        [Route("api/booking/param")]
        public IHttpActionResult Get(int roomId, DateTime date)
        {
            bool response = _bookingManager.CheckRoomAvailability(roomId, date);
            return Ok(response);
        }

    }
}
