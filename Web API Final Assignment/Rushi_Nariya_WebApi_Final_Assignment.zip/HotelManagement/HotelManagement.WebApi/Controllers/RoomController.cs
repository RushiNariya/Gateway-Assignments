﻿using HotelManagement.BAL.Interface;
using HotelManagement.Models;
using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace HotelManagement.WebApi.Controllers
{
    public class RoomController : ApiController
    {
        private readonly IRoomManager _roomManager;

        public RoomController(IRoomManager roomManager)
        {
            _roomManager = roomManager;
        }

        // GET: api/Room
        public IHttpActionResult Get()
        {
            List<Rooms> rooms = _roomManager.GetAllRooms();
            if (!rooms.Any())
            {
                return NotFound();
            }
            return Ok(rooms);
        }

        //Rooms By hotelId
        // GET: api/Room/5
        public IHttpActionResult Get(int id)
        {
            List<Rooms> rooms = _roomManager.GetRoom(id);
            if (!rooms.Any())
            {
                return NotFound();
            }
            return Ok(rooms);
        }

        // POST: api/Room
        public IHttpActionResult Post([FromBody]Rooms room)
        {
            string userId = User.Identity.GetUserId();
            if (userId == null)
            {
                return Unauthorized();
            }

            room.CreatedBy = userId;
            room.UpdatedBy = userId;

            string response = _roomManager.CreateRoom(room);
            if (response.Equals("Error"))
            {
                return NotFound();
            }
            return Ok();
        }

        // GET: api/room/param?city={city}&pincode={pincode}&price={price}&category={category}
        [Route("api/Room/param")]
        public IHttpActionResult Get(string city, string pincode, decimal price, string category)
        {
            List<Rooms> rooms = _roomManager.GetRooms(city, pincode, price, category);
            if (!rooms.Any())
            {
                return NotFound();
            }
            return Ok(rooms);
        }

        // PUT: api/Room/5
        //public void Put(int id, [FromBody]string value)
        //{
        //}

        //// DELETE: api/Room/5
        //public void Delete(int id)
        //{
        //}
    }
}
