﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Microsoft.AspNet.Identity;

namespace HotelManagement.WebApi.Controllers
{
    public class APIController : ApiController
    {
        [HttpGet]
        public string getuserId()
        {
            return User.Identity.GetUserId();
        }
    }
}
