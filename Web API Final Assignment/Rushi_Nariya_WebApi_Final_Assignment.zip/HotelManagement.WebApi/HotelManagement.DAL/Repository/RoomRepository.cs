﻿using HotelManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelManagement.DAL.Database;
using AutoMapper;

namespace HotelManagement.DAL.Repository
{
    public class RoomRepository : IRoomRepository
    {
        DateTime createdDate = DateTime.Now;

        private readonly HotelManagementEntities _dbContext;
        public RoomRepository()
        {
            _dbContext = new HotelManagementEntities();
        }

        public string CreateRoom(Rooms room)
        {
            try
            {
                if (room != null)
                {
                    Room entity = new Room();

                    var config = new MapperConfiguration(cfg => cfg.CreateMap<Rooms, Room>());
                    var mapper = new Mapper(config);

                    entity = mapper.Map<Room>(room);
                    entity.UpdatedDate = createdDate;
                    entity.CreatedDate = createdDate;

                    _dbContext.Rooms.Add(entity);
                    _dbContext.SaveChanges();

                    return "created";
                }
                return "Error";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public List<Rooms> GetAllRooms()
        {
            var entities = _dbContext.Rooms.OrderBy(x => x.Price).ToList();

            List<Rooms> rooms = new List<Rooms>();

            var config = new MapperConfiguration(cfg => cfg.CreateMap<Room, Rooms>());
            var mapper = new Mapper(config);

            if (entities != null)
            {
                foreach (var item in entities)
                {
                    Rooms room = new Rooms();
                    room = mapper.Map<Rooms>(item);
                    rooms.Add(room);
                }
            }
            return rooms;
        }

        public List<Rooms> GetRoom(int hotelId)
        {
            var entities = _dbContext.Rooms.Where(x => x.HotelId == hotelId).OrderBy(x => x.Price).ToList();

            List<Rooms> rooms = new List<Rooms>();

            var config = new MapperConfiguration(cfg => cfg.CreateMap<Room, Rooms>());
            var mapper = new Mapper(config);

            if (entities != null)
            {
                foreach (var item in entities)
                {
                    Rooms room = new Rooms();
                    room = mapper.Map<Rooms>(item);
                    rooms.Add(room);
                }
            }
            return rooms;
        }

        public List<Rooms> GetRooms(string city, string pincode, decimal price, string category)
        {
            var entities = _dbContext.Rooms.Where(x => x.Hotel.City.Equals(city) && x.Hotel.PinCode.Equals(pincode) && x.Price <= price && x.Category.Equals(category)).OrderBy(x => x.Price).ToList();

            List<Rooms> rooms = new List<Rooms>();

            var config = new MapperConfiguration(cfg => cfg.CreateMap<Room, Rooms>());
            var mapper = new Mapper(config);

            if (entities != null)
            {
                foreach (var item in entities)
                {
                    Rooms room = new Rooms();
                    room = mapper.Map<Rooms>(item);
                    rooms.Add(room);
                }
            }
            return rooms;
        }
    }
}
