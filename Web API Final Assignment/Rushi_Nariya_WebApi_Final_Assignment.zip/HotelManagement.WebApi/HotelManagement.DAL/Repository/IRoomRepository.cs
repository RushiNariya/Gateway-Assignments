﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelManagement.Models;

namespace HotelManagement.DAL.Repository
{
    public interface IRoomRepository
    {
        List<Rooms> GetAllRooms();
        string CreateRoom(Rooms room);
        List<Rooms> GetRoom(int hotelId);
        List<Rooms> GetRooms(string city, string pincode, decimal price, string category);
    }
}
