﻿using HotelManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelManagement.DAL.Database;
using AutoMapper;

namespace HotelManagement.DAL.Repository
{
    public class HotelRepository : IHotelRepository
    {
        DateTime createdDate = DateTime.Now;

        private readonly HotelManagementEntities _dbContext;
        public HotelRepository()
        {
            _dbContext = new HotelManagementEntities();
        }
        public string CreateHotel(Hotels hotel)
        {
            try
            {
                if(hotel != null)
                {
                    Hotel entity = new Hotel();
                    var config = new MapperConfiguration(cfg => cfg.CreateMap<Hotels, Hotel>());
                    var mapper = new Mapper(config);

                    entity = mapper.Map<Hotel>(hotel);
                    entity.CreatedDate = createdDate;
                    entity.UpdatedDate = createdDate;

                    _dbContext.Hotels.Add(entity);
                    _dbContext.SaveChanges();
                    
                    return "created";
                }
                else
                {
                    return "Error";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public List<Hotels> GetAllHotels()
        {
            var entities = _dbContext.Hotels.OrderBy(x => x.Name).ToList();

            List<Hotels> hotels = new List<Hotels>();

            var config = new MapperConfiguration(cfg => cfg.CreateMap<Hotel, Hotels>());
            var mapper = new Mapper(config);

            if (entities != null)
            {
                foreach (var item in entities)
                {
                    Hotels hotel = new Hotels();
                    hotel = mapper.Map<Hotels>(item);
                    hotels.Add(hotel);
                }
            }
            return hotels;
        }

        public Hotels GetHotel(int id)
        {
            var entity = _dbContext.Hotels.Where(x => x.Id == id).FirstOrDefault();

            Hotels hotel = new Hotels();

            var config = new MapperConfiguration(cfg => cfg.CreateMap<Hotel, Hotels>());
            var mapper = new Mapper(config);

            if (entity != null)
            {
                hotel = mapper.Map<Hotels>(entity);
            }
            return hotel;
        }
    }
}
