﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HotelManagement.DAL.Database;
using AutoMapper;
using HotelManagement.Models;

namespace HotelManagement.DAL.Repository
{
    public class BookingRepository : IBookingRepository
    {
        string defaultStatus = "Optional";
        DateTime createdDate = DateTime.Now;

        private readonly HotelManagementEntities _dbContext;
        public BookingRepository()
        {
            _dbContext = new HotelManagementEntities();
        }

        public bool CheckRoomAvailability(int roomId, DateTime date)
        {
            var availability = _dbContext.Bookings.Where(x => x.RoomId == roomId && x.BookingDate == date && !(x.Status.Equals("Deleted"))).FirstOrDefault();
            if(availability == null)
            {
                return true; 
            }
            return false;
        }

        public string CreateBooking(Bookings booking)
        {
            try
            {    
                if(booking != null || CheckRoomAvailability(booking.RoomId, booking.BookingDate))
                {
                    Booking entity = new Booking();

                    var config = new MapperConfiguration(cfg => cfg.CreateMap<Bookings, Booking>());
                    var mapper = new Mapper(config);

                    entity = mapper.Map<Booking>(booking);
                    entity.Status = defaultStatus;

                    _dbContext.Bookings.Add(entity);
                    _dbContext.SaveChanges();

                    return "created";
                }
                return "Error";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public string DeleteBooking(int bookingId)
        {
            return UpdateBooking(bookingId, "Deleted");
        }

        public string UpdateBooking(Bookings booking)
        {
            try
            {
                var entity = _dbContext.Bookings.Find(booking.Id);

                if (entity != null || CheckRoomAvailability(booking.RoomId, booking.BookingDate))
                {
                    entity.RoomId = booking.RoomId;
                    entity.BookingDate = booking.BookingDate;
                    entity.BookingBy = booking.BookingBy;
                    entity.Status = booking.Status;
                    entity.BookingDate = createdDate;

                    _dbContext.SaveChanges();

                    return "Updated";
                }
                return "null";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public string UpdateBooking(int bookingId, string status)
        {
            try
            {
                var entity = _dbContext.Bookings.Find(bookingId);

                if (entity != null)
                {
                    entity.Status = status;
                    _dbContext.SaveChanges();

                    return "StatusUpdated";
                }

                return "null";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    }
}
