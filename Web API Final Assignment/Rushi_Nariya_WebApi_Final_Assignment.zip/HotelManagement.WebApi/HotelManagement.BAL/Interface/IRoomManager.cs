﻿using HotelManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagement.BAL.Interface
{
    public interface IRoomManager
    {
        List<Rooms> GetAllRooms();
        string CreateRoom(Rooms room);
        List<Rooms> GetRoom(int hotelId);
        List<Rooms> GetRooms(string city, string pincode, decimal price, string category);
    }
}
